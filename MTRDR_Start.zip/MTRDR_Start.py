#Raw Data directory
#https://pds-geosciences.wustl.edu/mro/mro-m-crism-5-rdr-mptargeted-v1/mrocr_4001/mtrdr/

#Picking one set of images at random:
#https://pds-geosciences.wustl.edu/mro/mro-m-crism-5-rdr-mptargeted-v1/mrocr_4001/mtrdr/2010/2010_034/frt00016438/

#I beleive "su164j" data is for "Mineralogical analysis at full res"
#Although "if164j" is for "Advanced mineralogical analysis"
#Which to use?

#I downloaded the sul dataset.

import rasterio
import numpy as np
from rasterio.plot import show
import matplotlib.pyplot as plt

#Import the dataset
dataset = rasterio.open('frt00016438_07_su164j_mtr3.img')

## Note the "07" means this is the 7th image of data for this area, so there are at least 7 datasets to obtain.

#Basic Info
print('Image filename: {n}\n'.format(n=dataset.name))
print('Number of bands in image: {n}\n'.format(n=dataset.count))
print('Band names: {dt}'.format(dt=dataset.tags()))

#Plot the surface
R770_Data = dataset.read(1)
R770_Data_Mask = np.where(R770_Data < 65535, R770_Data, np.nan)
show(R770_Data_Mask, transform=dataset.transform, cmap='gray')

#Select another band
BD530_2_Data = dataset.read(3)
BD530_2_Data_Mask = np.where(BD530_2_Data < 65535, BD530_2_Data, np.nan)
show(BD530_2_Data_Mask, transform=dataset.transform, cmap='gray')
rasterio.plot.show_hist(BD530_2_Data_Mask, bins=50, histtype='stepfilled', lw=0.0, stacked=False, alpha=0.3)

#Stack Multiple Bands
BD860_2_Data = dataset.read(7)
BD860_2_Data_Mask = np.where(BD860_2_Data < 65535, BD860_2_Data, np.nan)
BDI1000VIS_Data = dataset.read(10)
BDI1000VIS_Data_Mask = np.where(BDI1000VIS_Data < 65535, BDI1000VIS_Data, np.nan)
Stack = []
Stack = np.array([BD860_2_Data_Mask, BDI1000VIS_Data_Mask])
rasterio.plot.show_hist(Stack, bins=50, histtype='stepfilled', lw=0.0, stacked=False, alpha=0.3)

#Plot both bands together
fig, ax = plt.subplots()
ax.scatter(np.ndarray.flatten(BD860_2_Data_Mask), np.ndarray.flatten(BDI1000VIS_Data_Mask))
ax.set_xlabel('BD860_2_Data')
ax.set_ylabel('BDI1000VIS_Data')
fig.show()

test = 2